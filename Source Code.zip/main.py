import random
import time
import math
import os
import colorama

# General game

class Shell:
    def skip(self, list: str, index: int):
        print(f"You skipped {list[index].shell}.")

class LiveRound(Shell):
    def __init__(self):
        self.shell = "live round"

    def shot(self, game_object, monster: bool):
        if monster:
            game_object.monster.reduce_lives()
        else:
            game_object.you.reduce_lives()
        return 1

class Blank(Shell):
    def __init__(self):
        self.shell = "blank"

    def shot(self, game_object, monster: bool):
        return 0

class Member:
    def __init__(self, lives: int):
        self.lives = lives
    
    def reduce_lives(self, how_much: int = 1):
        if how_much > self.lives:
            self.lives = 0
        else:
            self.lives -= how_much

def generate(count: int) -> list[list[Blank, LiveRound], list[int]]:
    shells = []
    shell_list = [LiveRound(), Blank()]
    live_rounds = 0
    blanks = 0

    for _ in range(0, count):
        selected = random.choice(shell_list)
        if type(selected) == Blank:
            blanks += 1
        elif type(selected) == LiveRound:
            live_rounds += 1
        shells.append(selected)

    return shells, [blanks, live_rounds]

class MonsterAI:
    def __init__(self, blanks: int, live_rounds: int) -> None:
        self.currentblanks = blanks
        self.currentliverounds = live_rounds

    def think(self) -> list[str, int]:
        if self.currentblanks == 0:
            return "shot", 2
        elif self.currentblanks < self.currentliverounds:
            return "shot", 5
        elif self.currentblanks > self.currentliverounds:
            rng = random.choice(["shot", "skip"])
            return rng, 5
        elif self.currentblanks == self.currentliverounds:
            rng = random.choice(["shot", "skip"])
            return rng, 5
        elif self.currentliverounds == 0:
            return "skip", 2
    
    def blankshot(self) -> None:
        self.currentblanks -= 1
    
    def liveroundshot(self) -> None:
        self.currentliverounds -= 1


class Game:
    def __init__(self, monster: Member, you: Member, monsterai: MonsterAI) -> None:
        self.monster = monster
        self.you = you
        self.monsterai = monsterai

    def you_shot(self, list: list[Blank, LiveRound], index: int):
        shot_status = list[index].shot(self, True)
        if shot_status == 1:
            print(f"{colorama.Fore.RED}Monster got shot!{colorama.Fore.RESET}")
            self.monsterai.liveroundshot()
            time.sleep(1)
            if self.monster.lives == 0:
                os.system("CLS")
                print(f"{colorama.Fore.GREEN}Monster is dead. You are free now.")
                time.sleep(5)
                exit()
            else:
                print(f"{colorama.Fore.RED}He has {self.monster.lives} lives now.{colorama.Fore.RESET} \n")
        else:
            self.monsterai.blankshot()
            print(f"{colorama.Fore.GREEN}That was a blank. Monster didn't get any damage.{colorama.Fore.RESET} \n")
        time.sleep(5)

    def monster_shot(self, list: list[Blank, LiveRound], index: int):
        shot_status = list[index].shot(self, False)
        if shot_status == 1:
            print(f"{colorama.Fore.RED}You got shot!{colorama.Fore.RESET}")
            self.monsterai.liveroundshot()
            time.sleep(1)
            if self.you.lives == 0:
                os.system("CLS")
                print(f"{colorama.Fore.RED}You are dead.")
                time.sleep(5)
                exit()
            else:
                print(f"{colorama.Fore.RED}You have {self.you.lives} lives now. Be careful!{colorama.Fore.RESET} \n")
        else:
            self.monsterai.blankshot()
            print(f"{colorama.Fore.GREEN}That was a blank. You didn't get any damage.{colorama.Fore.RESET} \n")
        time.sleep(5)
    
    def you_skip(self, list: list[Blank, LiveRound], index: int):
        print(f"You skipped your shell. You had {list[index].shell} in the chamber that time. \n")
        if type(list[index].shell) == LiveRound:
            self.monsterai.liveroundshot()
        else:
            self.monsterai.blankshot()
        time.sleep(2)

    def monster_skip(self, list: list[Blank, LiveRound], index: int):
        print(f"Monster skipped his shell. He had {list[index].shell} in the chamber that time. \n")
        if type(list[index].shell) == LiveRound:
            self.monsterai.liveroundshot()
        else:
            self.monsterai.blankshot()
        time.sleep(2)

    def generate_order(self, wait_time: int) -> list[Blank, LiveRound]:
        ask = int(input("How many shells do you want to insert? "))
        if ask != int(0) and ask != int(1):
            print(f"Inserting {ask} shells... (this may take ~ {math.floor(ask * wait_time)} seconds)")
            time.sleep(ask * wait_time)
            generation = generate(ask)
            order = generation[0]
            shell_count = generation[1]
            live_rounds = shell_count[1]
            blanks = shell_count[0]
            lr_and_bl_text = ["live rounds", "blanks"]
            if live_rounds == 1:
                lr_and_bl_text[0] = lr_and_bl_text[0][:len(lr_and_bl_text[0]) - 1]
            if blanks == 1:
                lr_and_bl_text[1] = lr_and_bl_text[1][:len(lr_and_bl_text[1]) - 1]
            
            print("The shells were inserted.")
            time.sleep(1)
            print(f"Now there is {blanks} {lr_and_bl_text[1]}, and {live_rounds} {lr_and_bl_text[0]}. \n")
            self.monsterai.currentblanks = blanks
            self.monsterai.currentliverounds = live_rounds

            return order
        else:
            print(f"{colorama.Fore.RED} You can't insert 0 or 1 shell.")
            print(f"{colorama.Fore.RESET}")
            time.sleep(3)
            exit()
            

    def monster_turn(self, list: list[Blank, LiveRound], index: int) -> None:
        print("Monster is thinking...")
        thoughts = self.monsterai.think()
        thinktime = thoughts[1]
        choice = thoughts[0]
        time.sleep(thinktime)
        if choice == "shot":
            print("Monster is taking aim...")
            time.sleep(3)
            self.monster_shot(list, index)
        elif choice == "skip":
            self.monster_skip(list, index)
            return "skip"

    def your_turn(self, list: list[Blank, LiveRound], index: int) -> None:
        choice = int(input("Do you want to shoot or to skip this shell? (write 0 or 1) "))
        if choice != 0 and choice != 1:
            print("You wrote a wrong number.")
            time.sleep(3)
            exit()
        time.sleep(1)
        selections_list = ["shot", "skip"]
        choice = selections_list[choice]
        if choice == "shot":
            print("You are taking aim...")
            time.sleep(3)
            self.you_shot(list, index)
        elif choice == "skip":
            self.you_skip(list, index)
            return "skip"
        
            
def main(monster: Member, you: Member, monsterai: MonsterAI, game: Game):
    try:
        order = game.generate_order(0.5)
        time.sleep(3)
        os.system("CLS")
        count = 1
        for shell in order:
            if count % 2 == 0:
                os.system("CLS")
                print("Now it is the monster turn.")
                time.sleep(2)
                data = game.monster_turn(order, order.index(shell))
                if data == "skip":
                    if order.index(shell) == -1:
                        pass
                    else:
                        game.monster_turn(order, order.index(shell))
            else:
                os.system("CLS")
                print("Now it is your turn.")
                time.sleep(2)
                data = game.your_turn(order, order.index(shell))
                if data == "skip":
                    if order.index(shell) == -1:
                        pass
                    else:
                        game.your_turn(order, order.index(shell))
            count += 1

        os.system("CLS")
        ask = input(f"{colorama.Fore.RED}The monster didn't die and he wants to play again. Agree? (Y/N) {colorama.Fore.RESET}")
        if ask == "Y":
            os.system("CLS")
            main(monster, you, monsterai, game)
        else:
            exit()
        time.sleep(5)
        exit()

    except Exception as ex:
        print("We had error. Maybe, you wrote something that game didn't understand. Error code is:")
        print(ex)
        time.sleep(3)
        exit()

# Text generation

pyroulette_text = f"""{colorama.Fore.RED}
██████╗░██╗░░░██╗██████╗░░█████╗░██╗░░░██╗██╗░░░░░███████╗████████╗████████╗███████╗
██╔══██╗╚██╗░██╔╝██╔══██╗██╔══██╗██║░░░██║██║░░░░░██╔════╝╚══██╔══╝╚══██╔══╝██╔════╝
██████╔╝░╚████╔╝░██████╔╝██║░░██║██║░░░██║██║░░░░░█████╗░░░░░██║░░░░░░██║░░░█████╗░░
██╔═══╝░░░╚██╔╝░░██╔══██╗██║░░██║██║░░░██║██║░░░░░██╔══╝░░░░░██║░░░░░░██║░░░██╔══╝░░
██║░░░░░░░░██║░░░██║░░██║╚█████╔╝╚██████╔╝███████╗███████╗░░░██║░░░░░░██║░░░███████╗
╚═╝░░░░░░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░░╚═════╝░╚══════╝╚══════╝░░░╚═╝░░░░░░╚═╝░░░╚══════╝{colorama.Fore.WHITE} \n"""

print(pyroulette_text)
print(f"{colorama.Fore.RED} - Basic russian roulette game made on python")
print(f"{colorama.Fore.RED} - Made by _thecoffee_ (https://github.com/FoxGruop/)")
print(f"{colorama.Fore.RED} - Version: 1.0")
print("")
ask = input(f"Do you wanna play the game? (Y/N) {colorama.Fore.GREEN}")
if ask == "Y":
    print(f"{colorama.Fore.RESET}")
    os.system("CLS")
    monster = Member(3)
    you = Member(3)
    monsterai = MonsterAI(0, 0)
    game = Game(monster, you, monsterai)
    main(monster, you, monsterai, game)
else:
    exit()
        

